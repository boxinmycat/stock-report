# v9.9 자동 리포트 운영 가이드

## 1. 기본 구조
- `docs/index.html`: 오늘 리포트 홈페이지
- `docs/reports/YYYYMMDD/index.html`: 날짜별 리포트 보관
- `html_report_package_YYYYMMDD.zip`: HTML 리포트 묶음

## 2. GitHub Pages 방식
1. GitHub 저장소를 만듭니다.
2. 이 노트북과 `automation/` 폴더를 저장소에 올립니다.
3. GitHub Secrets에 필요한 키를 넣습니다.
   - `OPEN_DART_API_KEY`
   - `NAVER_CLIENT_ID`
   - `NAVER_CLIENT_SECRET`
4. `.github/workflows/daily-report.yml`을 저장소 루트의 `.github/workflows/`로 복사합니다.
5. GitHub Pages를 `docs/` 폴더 기준으로 설정합니다.

## 3. Google Drive 방식
- 현재는 스켈레톤만 포함되어 있습니다.
- Drive API 인증을 설정한 뒤 `automation/scripts/upload_to_drive.py`에 업로드 코드를 연결하면 됩니다.

## 4. 권장 운영
- 자동매매가 아니라 `자동 리포트 생성 → 사람이 확인 → 수동 매매` 흐름을 권장합니다.
- 매매 전 HTS/MTS에서 현재가, 호가, 공시, 뉴스는 반드시 최종 확인하세요.
