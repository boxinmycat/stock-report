# v10.0 자동 리포트 설정 안내

## 1단계: Colab 수동 + Drive 저장으로 먼저 테스트
1. 노트북 첫 설정에서 `USE_GOOGLE_DRIVE=True`, `REPORT_ROOT_MODE='DRIVE'`로 바꿉니다.
2. Colab Secrets에 필요한 키를 저장합니다.
   - `OPEN_DART_API_KEY` 또는 `DART_API_KEY`
   - `NAVER_CLIENT_ID`
   - `NAVER_CLIENT_SECRET`
3. `/MyDrive/stock_report/holdings/` 폴더에 전날 보유 파일을 넣습니다. 예: `20260527.xlsx`
4. 런타임 다시 시작 후 전체 실행합니다.
5. 결과는 `/MyDrive/stock_report/reports/YYYYMMDD/`와 `/MyDrive/stock_report/latest/`에 저장됩니다.

## 2단계: GitHub 자동 실행 준비
1. GitHub에 private repository를 만듭니다.
2. 이 패키지의 노트북과 `automation_v10/` 폴더를 업로드합니다.
3. GitHub repository Settings → Secrets and variables → Actions에 API 키를 등록합니다.
4. Actions 탭에서 `daily-stock-report`를 수동 실행해 테스트합니다.
5. 정상 작동하면 매일 KST 오전 8시 자동 실행됩니다.

## 3단계: HTML 보기
- `stock_report/latest/html/index.html` 또는 `docs/index.html`을 열면 최신 리포트를 볼 수 있습니다.
- GitHub Pages를 사용할 경우 민감 정보가 공개되지 않도록 저장소 공개 범위를 반드시 확인하세요.

## 주의
- 이 리포트는 투자 판단 보조용이며 매수·매도 권유가 아닙니다.
- 실제 주문 전 MTS/HTS 현재가, 뉴스, 공시, 손실한도를 반드시 확인하세요.
